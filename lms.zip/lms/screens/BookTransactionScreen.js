import React,{Component} from 'react';
import {View, Image, TouchableOpacity, TextInput, Text, StyleSheet, FlatList,ListView,Alert} from 'react-native';


export default class BookTransactionScreen extends Component{
  constructor(){
    super();
    this.state={
      allData:[],
    }
  }

    getListViewItem = (item) => {  
        Alert.alert(item.key);  
    }  

  autoPopulate=()=>{
    var temp=['Books','Book','Bookish'];
    this.setState({allData:temp});

    return(
        <ListView

        />

    );
  }


  componentDidMount(){
    this.autoPopulate();
  }

  render(){
    const data=this.state.data;
    console.log(data);
    return(
        <View>      
            <Image source={require('../assets 1/booklogo.jpg')} style={styles.logo}/>
            <Text style={styles.title}>WILEY</Text>



            <TextInput 
              placeholder="Book ID"
              style={styles.textinp}
              onChangeText={(text)=>{this.autoPopulate()}}
            />
            <TextInput 
              placeholder="Student ID"
              style={styles.textinp}
            />


          <View style={styles.scanner}>
            <TouchableOpacity style={styles.scanButtons}>
                <Text style={styles.textButton}>Scan Book ID</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.scanButtons}>
                <Text style={styles.textButton}>Scan Student ID</Text>
            </TouchableOpacity>
          </View>
        </View>
    );
  }
}

const styles=StyleSheet.create({
  logo:{
    width:200,
    height:200,
    alignSelf:'center',
    marginTop:50,
  },
  title:{
    fontSize:20,
    textAlign:'center',
    fontFamily:'Cursive',
    fontWeight:'bold',
  },
  textinp:{
      borderWidth:1,
      width:200,
      alignSelf:'center',
      marginTop:20,
      textAlign:'center',
  },
  scanButtons:{
      backgroundColor:'#f10fae',
      width:150,
      alignSelf:'center',
      marginTop:20,
      borderRadius:20,
      height:25,
      marginLeft:20,
  },
  textButton:{
      textAlign:'center',
      alignItems:'center',
      justifyContent:'center',
  },
  scanner:{
    flexDirection:'row',
    gap:10,
    marginLeft:10,
  }
})

